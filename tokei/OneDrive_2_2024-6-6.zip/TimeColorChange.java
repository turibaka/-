import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeColorChange extends JFrame {
    private static final Color Color = null;
    private JLabel dateTimeLabel;

    public TimeColorChange() {
        setTitle("Time Color Change");
        setSize(600, 100);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        dateTimeLabel = new JLabel();
        dateTimeLabel.setFont(new Font("Arial",Font.ITALIC,50));
        updateDateTime();
        add(dateTimeLabel);

        Timer timer = new Timer(1000, e -> {
            updateDateTime();
            changeColor();
        });
        timer.start();

        setVisible(true);
    }

    private void updateDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date now = new Date();
        dateTimeLabel.setText(sdf.format(now));
    }

    private void changeColor() {
        SimpleDateFormat minuteFormat = new SimpleDateFormat("mm");
        Date now = new Date();
        int minute = Integer.parseInt(minuteFormat.format(now));

        // 1分ごとに色を変える
        if (minute % 2 == 0) {
            dateTimeLabel.setForeground(Color.PINK);
        } else {
            dateTimeLabel.setForeground(Color.BLUE);
        }
    }
}
