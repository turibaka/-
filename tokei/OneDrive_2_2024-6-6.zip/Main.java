public class Main extends Object{
    public static void main(String[] args) {
        new TimeColorChange();
    }

}